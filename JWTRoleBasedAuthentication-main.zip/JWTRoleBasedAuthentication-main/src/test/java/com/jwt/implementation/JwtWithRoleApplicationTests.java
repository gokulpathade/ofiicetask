package com.jwt.implementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtWithRoleApplicationTests {

	@Test
	void contextLoads() {
	}

}
