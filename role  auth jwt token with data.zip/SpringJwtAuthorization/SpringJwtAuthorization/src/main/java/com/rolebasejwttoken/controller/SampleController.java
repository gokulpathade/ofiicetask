package com.rolebasejwttoken.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api")
@Api(tags = "Sample Controller", description = "Operations related to samples")
public class SampleController {

    @ApiOperation(value = "Get a sample")
    @GetMapping("/sample")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "JWT token", required = true, dataType = "string", paramType = "header")
    })
    public ResponseEntity<String> getSample() {
        return ResponseEntity.ok("Sample data");
    }
}
