package com.rolebasejwttoken.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rolebasejwttoken.model.FieldInspection;
import com.rolebasejwttoken.model.User;
import com.rolebasejwttoken.repository.FieldInspectionRepository;

@Service
public class FieldInspectionService {

	@Autowired
	private FieldInspectionRepository repository;

	@Autowired
	private UserService userService;

	public List<FieldInspection> getALL() {
		return repository.findAll();
	}

	public FieldInspection getById(int id) {
		return repository.findById(id).get();

	}

//	  public FieldInspection saveFieldInspection(FieldInspection fieldInspection, User user) {
//	      
//	    }

	public void deleteById(int id) {
		repository.deleteById(id);

	}

//		

	/**
	 * // Update USER DETAILS USING USER ID HERE
	 */

	public FieldInspection updateData(FieldInspection field, int id) {
		Optional<FieldInspection> target = repository.findById(id);
		if (target.isPresent()) {
			FieldInspection aleadyExist = target.get();

			aleadyExist.setName(field.getName());
			aleadyExist.setDate(field.getDate());
			aleadyExist.setLocation(field.getLocation());
			aleadyExist.setProgress(field.getProgress());
			aleadyExist.setRemark(field.getRemark());
			aleadyExist.setStatus(field.getStatus());
			return repository.save(field);
		}
		throw new IllegalArgumentException("FieldInspection data not found " + id);
	}

     //	SAVE NEW DATA HERE 
	public FieldInspection saveFieldInspection(FieldInspection fieldInspection, Integer userId) {
		if (userId == null) {
			// Handle invalid userId
			throw new IllegalArgumentException("User ID cannot be null");
		}
		// Get the User entity by its ID
		User user = userService.getById(userId);
		if (user == null) {
			// Handle case where user with specified ID doesn't exist
			throw new IllegalArgumentException("User with ID " + userId + " not found");
		}
		// Set the User entity for the FieldInspection
		fieldInspection.setUser(user);
		try {
			// Save the FieldInspection
			return repository.save(fieldInspection);
		} catch (Exception e) {
			// Handle any exceptions during saving
			throw new RuntimeException("Error saving field inspection: " + e.getMessage());
		}
	}

}
