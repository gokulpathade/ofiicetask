package com.rolebasejwttoken.model;






public enum Role {
	ROLE_ADMIN,
	ROLE_FIELDENGINEER,
	ROLE_PRINCEPALENGINEER
   
       
       
       
       
}
       
       
       
       
       
       
       
       
//	    @ManyToOne
//	    @JoinColumn(name = "user_id") // adjust the column name accordingly
//	    private User user;
//	    
	    
//	    @ManyToMany(cascade = CascadeType.ALL)
////	    @ManyToOne
//		@JoinColumn(name = "userid")
//		// name should match the actual column name in your database
//		private User user;

//    @Override
//    public String getAuthority() {
//        return role;
//    }
//}
