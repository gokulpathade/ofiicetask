package com.rolebasejwttoken.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rolebasejwttoken.dto.UserDTO;
import com.rolebasejwttoken.model.FieldInspection;
import com.rolebasejwttoken.model.User;
import com.rolebasejwttoken.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api")
//@Api(tags = "User Management")
public class UserController {

	@Autowired
	private UserService userService;

	 @ApiOperation(value = "SAVE NEW USER DATA HERE", response = String.class)
	@PostMapping("/save")
	@Secured("ROLE_ADMIN")
	public ResponseEntity<User> saveUser(@RequestBody UserDTO userDto) {
		return ResponseEntity.ok(userService.save(userDto));

	}


	 @ApiOperation(value = "Get ALL USER DATA HERE", response = String.class)
	@GetMapping("/getall")
	@Secured("ROLE_ADMIN")
	public ResponseEntity<List<User>>  getAllUser() {

		Logger logger = LoggerFactory.getLogger(UserController.class);

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		// Log or inspect roles
		logger.info("User {} has roles: {}", authentication.getName(), authentication.getAuthorities());

		return ResponseEntity.ok(userService.getALL()) ;
	}

	 
	 
	 @ApiOperation(value = "GET USER DATA HERE USING USER ID", response = String.class)
	@GetMapping("/getuserbyid/{id}")
	public ResponseEntity<User> getById(@PathVariable("id") int id) {
		return ResponseEntity.ok( userService.getById(id));

	}
	 

	 @ApiOperation(value = "DELETE USER DATA HERE USING USER ID", response = String.class)
	@DeleteMapping("/deleteUser/{id}")
	@Secured("ROLE_ADMIN")
	public String deleteById(@PathVariable("id") int id) {
		userService.deleteById(id);

		return "user deleted successfully";
	}

	 
	 @ApiOperation(value = "Update USER DATA HERE USING USER ID", response = String.class)
	@PutMapping("/updateUser/{id}")
//	@Secured("ROLE_ADMIN")
	 public ResponseEntity<User>  updateData(@RequestBody User user, @PathVariable("id")int id) {
		 return ResponseEntity.ok( userService.updateData(user, id));
	 }
	 
		

	 
	 
	 
	 
	 
}




























































//@GetMapping("/getall")
////@RolesAllowed("ADMIN")
////@Secured({"ROLE_USER", "ROLE_ADMIN"})
//@Secured("ADMIN")
//public List<User> getAllUser() {
//return userService.getALL();
//}



//public UserDTO saveData(Use field) {
//return repository.save(field);
//
//}




//@GetMapping("/getall")
//@RolesAllowed("ROLE_ADMIN")
////@PreAuthorize("hasRole('ROLE_ADMIN')")
//public List< User> getAllUser(){
//	return userService.getAllUser();
//}

//
//public List<User> getALL() {
//return repository.findAll();
//}