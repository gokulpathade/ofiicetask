package com.rolebasejwttoken.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rolebasejwttoken.model.FieldInspection;
import com.rolebasejwttoken.model.User;
import com.rolebasejwttoken.service.FieldInspectionService;

@RestController
@RequestMapping("/api")
public class FieldInspectionController {

	@Autowired
	private FieldInspectionService service;

//	@PostMapping
//	public ResponseEntity<FieldInspection> create(@RequestBody @Valid FieldInspection fieldInspection) {
//		FieldInspection savedProduct = service.saveData(fieldInspection);
//		URI productURI = URI.create("/products/" + savedProduct.getId());
//		return ResponseEntity.created(productURI).body(savedProduct);
//	}

	@PostMapping("/saveFieldInspection/{userId}") // Define userId as a path variable
	public ResponseEntity<FieldInspection> saveData(@RequestBody FieldInspection field,
			@PathVariable("userId") Integer userId) {
		if (userId == null) {
			return ResponseEntity.badRequest().build();
		} else {
			return ResponseEntity.ok(service.saveFieldInspection(field, userId));
		}
	}

	/*
	 * GET DATA USING ID
	 */
	@GetMapping("/getdata/{id}")
	public ResponseEntity<FieldInspection> getById(@PathVariable("id") int id) {
		return ResponseEntity.ok(service.getById(id));

	}

	/*
	 * DATA USING ID
	 */
	@GetMapping("/getallFieldInspection")
	@Secured("ROLE_ADMIN")
	public ResponseEntity<List<FieldInspection>> list() {
		return ResponseEntity.ok(service.getALL());
	}

	/*
	 * DELETE DATA USING ID
	 */
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable("id") int id) {
		service.deleteById(id);

	}

	
	/**
	 * Update USER DETAILS USING USER ID HERE
	 */
	@PutMapping("/updatefield/{id}")
	@Secured({ "ROLE_ADMIN", "ROLE_PRINCEPALENGINEER" })
	public ResponseEntity<FieldInspection> updateData(@RequestBody FieldInspection field, @PathVariable("id") int id,
			Authentication authentication) {
		// Check if the user has the necessary roles
		if (authentication != null && authentication.getAuthorities().stream()
				.anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_PRINCEPALENGINEER"))) {
			// If user has ROLE_PRINCEPALENGINEER role, return message that they are not
			// allowed to update
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null); // Or return a suitable response
		}

		// If user has ROLE_ADMIN role or any other permitted role, proceed with the
		// update
		return ResponseEntity.ok(service.updateData(field, id));
	}

}
