import React from 'react'
import NavBar from '../dashboard/NavBar'
import SideBar from '../dashboard/SideBar'

function EmployeeDetails() {
  return (
    <>
    <NavBar/>
    <SideBar/>
    
        <div>EmployeeDetails</div>

    
    </>
  )
}

export default EmployeeDetails