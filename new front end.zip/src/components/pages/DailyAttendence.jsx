import React from 'react'
import NavBar from '../dashboard/NavBar'
import SideBar from '../dashboard/SideBar'

function DailyAttendence() {
  return (
    <>
    <NavBar/>
    <SideBar/>
    
       <div>DailyAttendence</div>

    
    </>
  )
}

export default DailyAttendence