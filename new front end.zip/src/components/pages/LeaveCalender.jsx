import React from 'react'

function LeaveCalender() {
  return (
    <div>LeaveCalender</div>
  )
}

export default LeaveCalender