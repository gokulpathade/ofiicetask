import React from 'react'

function UserApplyLeave() {
  return (
    <div>UserApplyLeave</div>
  )
}

export default UserApplyLeave