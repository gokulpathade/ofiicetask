import React from 'react'

function UserLeaveBalance() {
  return (
    <div>UserLeaveBalance</div>
  )
}

export default UserLeaveBalance