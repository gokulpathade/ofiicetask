import React from 'react'

function UserReporting() {
  return (
    <div>UserReporting</div>
  )
}

export default UserReporting