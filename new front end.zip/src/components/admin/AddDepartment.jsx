import React from 'react'
import NavBar from '../dashboard/NavBar'
import SideBar from '../dashboard/SideBar'
// import SideBar from '../dashboard/ManagerSideBar'
import { Box, Table } from '@mui/material'




function AddDepartment() {

  return (
<>
<NavBar/>
<SideBar/>
{/* <SideBar/> */}

<div>AddDepartment</div>


</>
   
  )
}

export default AddDepartment