const config = {
    //  serverURL: 'http://172.25.10.216:4000',
    // serverURL: 'http://172.25.10.110:4000',
    serverURL:'http://localhost:8080',
    }
    
    export default config
    