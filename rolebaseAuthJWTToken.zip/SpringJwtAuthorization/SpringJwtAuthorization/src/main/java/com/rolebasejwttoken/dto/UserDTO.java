package com.rolebasejwttoken.dto;

import javax.persistence.Column;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.rolebasejwttoken.model.Role;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
public class UserDTO {
	
	private Integer id;

    @Column(nullable = false, length = 64)
    @NotBlank(message = "Name is required")
    @Size(max = 255, message = "Name must be at most 255 characters")
    private String Name;

    @Column(nullable = false, length = 50, unique = true)
    @Email(message = "Email should be valid")
    @NotBlank(message = "Email is required")
    @Size(max = 255, message = "Email must be at most 255 characters")
    private String email;

    @Column(nullable = false, length = 64)
    @NotBlank(message = "Password is required")
    @Size(min = 5, max = 64, message = "Password must be between 5 and 64 characters")
    private String password;


	private Role userRole;

}
