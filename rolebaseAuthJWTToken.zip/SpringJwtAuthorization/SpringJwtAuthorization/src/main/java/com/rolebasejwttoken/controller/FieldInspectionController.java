package com.rolebasejwttoken.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rolebasejwttoken.model.FieldInspection;
import com.rolebasejwttoken.service.FieldInspectionService;

@RestController
@RequestMapping("/auth")
public class FieldInspectionController {

	@Autowired
	private FieldInspectionService service;

//	@PostMapping
//	public ResponseEntity<FieldInspection> create(@RequestBody @Valid FieldInspection fieldInspection) {
//		FieldInspection savedProduct = service.saveData(fieldInspection);
//		URI productURI = URI.create("/products/" + savedProduct.getId());
//		return ResponseEntity.created(productURI).body(savedProduct);
//	}

	/*
	 * SAVE NEW RESOURCE NEW DATA
	 */
	
	@PostMapping("/saveFieldInspection")
	public ResponseEntity<FieldInspection> saveData(@RequestBody FieldInspection field) {
		return ResponseEntity.ok(service.saveData(field));

	}
	

	/*
	 * GET DATA USING ID 
	 */
	@GetMapping("/getdata/{id}")
	public ResponseEntity<FieldInspection> getById(@PathVariable("id") int id) {
		return ResponseEntity.ok(service.getById(id));

	}

	/*
	 *  DATA USING ID
	 */
	@GetMapping("/getallFieldInspection")
	@Secured("ROLE_ADMIN")
	public ResponseEntity<List<FieldInspection>> list() {
		return ResponseEntity.ok(service.getALL());
	}

	/*
	 * DELETE DATA USING ID
	 */
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable("id") int id) {
		service.deleteById(id);

	}

}
