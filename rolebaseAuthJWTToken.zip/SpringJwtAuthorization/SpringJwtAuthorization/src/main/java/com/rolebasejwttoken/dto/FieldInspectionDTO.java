package com.rolebasejwttoken.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FieldInspectionDTO {
	
	
	
	
	 private Integer id;

	    @Column(nullable = false, length = 255)
	    @NotBlank(message = "Name is required")
	    @Size( max = 255, message = "Name must be between 255 characters")
	    private String name;

	    @Column(nullable = false, length = 128)
	    @NotBlank(message = "Location is required")
	    @Size( max = 128, message = "Location must be between 255 characters")
	    private String location;

	    @Column(nullable = false)
	    @NotNull(message = "Progress is required")
	    @DecimalMin(value = "0.0", message = "Progress must be a positive number")
	    @DecimalMax(value = "100.0", message = "Progress must not exceed 100")
	    private Double progress;

	    @Column(nullable = false)
	    @NotNull(message = "Date is required")
//	    @FutureOrPresent(message = "Date must be in the present or future")
	    private Date date;

	    @Column(nullable = false, length = 255)
	    @NotBlank(message = "Status is required")
	    @Size(max = 128, message = "Status must be between 255 characters")
	    private String status;

	    @Column(nullable = false, length = 128)
	    @NotBlank(message = "Remark is required")
	    @Size( max = 128, message = "Remark must be between 255 characters")
	    private String remark;


}
